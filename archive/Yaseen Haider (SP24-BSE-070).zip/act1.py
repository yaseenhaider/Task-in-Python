list =[1,2,4,4,3,3,3,6,6,5]
print("\nList with the use of number")
print(list)

list=(1,2,'Geek',4,'for',6,'Geek')
print("\n list with the use of mixed values:")
print(list)