list=[1,2,3,4]
print("initial list:")
print(list)

list.insert(3,12)
list.insert(0,'Geeks')
print("\nlist after performing operation")
print(list)
