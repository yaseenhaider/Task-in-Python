list=[1,2,3,4]
print("intial list")
print(list)
list.extend([8,'Hamza','Yaseen'])
print( "\n list with extend:")
print(list)