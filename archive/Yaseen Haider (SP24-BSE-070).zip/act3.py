list=[]
print("intial blank list")
print(list)

list.append(1)
list.append(2)
list.append(3)
print("\n list after three adition")
print(list)

for i in range(1,4):
    list.append(i)
    print("\n list after addition of element from1-3:")
    print(list)

    list.append(5,6)
    print("\nlist after tupple")
    print(list)