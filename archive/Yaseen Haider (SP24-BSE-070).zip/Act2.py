list1=[]
print(len(list1))

list2=[10,20,14]
print(len(list2))